package com.vp.dao;

public class EmailRepository {

}
